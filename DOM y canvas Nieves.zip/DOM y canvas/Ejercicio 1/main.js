// ---- Ej 1: Hola mundo ----

console.log("Hola, mundo!");

//document.body.innerHTML = '<h1>Hola, mundo!</h1>'; // Esto no saca nada en pantalla

window.onload = function ()  // Esto si
{
  document.body.innerHTML = '<h1>Hola, mundo!</h1>';
};